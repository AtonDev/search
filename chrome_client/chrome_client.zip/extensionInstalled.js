window.location.href = "https://alts.io/search";
